.. _authors:
.. include:: ../../.github/AUTHORS.rst
