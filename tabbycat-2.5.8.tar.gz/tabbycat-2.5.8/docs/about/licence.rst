.. include:: ../../LICENSE.rst
