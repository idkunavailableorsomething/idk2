.. _contributing:
.. include:: ../../.github/CONTRIBUTING.rst
