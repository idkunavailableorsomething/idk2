default_app_config = 'adjfeedback.apps.AdjFeedbackConfig'
