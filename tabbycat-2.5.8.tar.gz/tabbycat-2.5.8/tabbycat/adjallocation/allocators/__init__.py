from .base import registry
from .dumb import DumbAllocator
from .hungarian import ConsensusHungarianAllocator, VotingHungarianAllocator
