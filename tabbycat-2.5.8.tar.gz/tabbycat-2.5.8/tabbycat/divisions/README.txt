Support for divisions/leagues has been removed in Tabbycat 2.4.
