default_app_config = 'checkins.apps.CheckinsConfig'
