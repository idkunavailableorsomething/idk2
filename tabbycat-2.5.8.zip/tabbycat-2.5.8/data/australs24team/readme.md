Attribution
===========

The fake identities in this dataset were generated using the [Fake Name Generator](http://www.fakenamegenerator.com/), and are used under the [CC BY-SA 3.0 US licence](https://creativecommons.org/licenses/by-sa/3.0/us/).
