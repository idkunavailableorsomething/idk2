from dynamic_preferences.registries import PerInstancePreferenceRegistry


class TournamentPreferenceRegistry(PerInstancePreferenceRegistry):
    pass


tournament_preferences_registry = TournamentPreferenceRegistry()
