default_app_config = 'breakqual.apps.BreakQualConfig'
