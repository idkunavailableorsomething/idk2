default_app_config = 'adjallocation.apps.AdjAllocationConfig'
