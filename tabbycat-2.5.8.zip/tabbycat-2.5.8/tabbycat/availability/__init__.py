default_app_config = 'availability.apps.AvailabilityConfig'
